// Copy these values into js/config.js.
// Use only the project's publishable/anon key in browser code.
export const SUPABASE_URL = "https://YOUR_PROJECT.supabase.co";
export const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
export const APP_MODE = "auto";
