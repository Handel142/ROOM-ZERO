# ROOM ZERO — Stable Foundation

A mobile-first, installable web app foundation for ROOM ZERO. This package focuses on a reliable interface and working local interactions before the online multiplayer engine is enabled.

## Included

- Responsive ROOM ZERO landing page.
- Working light/dark theme switch with saved preference.
- Working player-name dialog.
- Working create-room flow with configurable capacity and six-character room code.
- Working local join-room flow, lobby, chat, emoji reactions, copy/share actions and leave-room action.
- Playable Brain Battle practice questions with scoring and next-question flow.
- Information dialogs for The Impostor, The Mystery and the future game modes.
- PWA manifest, icon and updated service worker cache.
- Netlify deployment configuration.
- Supabase starter schema retained in `supabase/schema.sql` for the later online integration stage.

## Important behaviour

The status pill intentionally says **Local preview**. Room creation, joining and chat currently use this browser's local storage. This means a room created on one phone cannot yet be joined from another phone. Supabase credentials alone do not enable online rooms: the secure room APIs and Realtime subscriptions still need to be implemented and tested.

No Supabase secret or service-role key is required for this local build. Do not put a service-role key in frontend files.

## Deploy to Netlify

1. Extract the ZIP.
2. Open the `ROOM_ZERO` folder.
3. Upload the files and folders inside `ROOM_ZERO` to the root of your GitHub repository (not the ZIP file itself).
4. In Netlify, import that GitHub repository.
5. Leave the build command empty and set the publish directory to `.`.
6. Deploy. Netlify serves the site over HTTPS, which is needed for PWA installation.

If using GitHub in a browser, create the repository first, then use **Add file → Upload files** and drag the contents of this folder into the upload area. GitHub does not upload a folder as one ordinary file; the ZIP is convenient for transferring the complete project, but the repository must contain the extracted files.

## Test locally

Run a local web server from this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Current scope and next stage

This is a stable local foundation, not a finished multiplayer platform. The next engineering stage is the actual Supabase integration: anonymous player sessions, room creation/join RPCs, Realtime presence and state, server-authoritative game progression, private Impostor roles, reconnection and the owner dashboard. These must be implemented and tested separately before online multiplayer is advertised as working.
